<?php
    $servername = "localhost";
    $username = "id16218880_bscs";
    $password = "J!\-~q!r]fZJf0EH";
    $dbname = "id16218880_buceils";
    
    $conn = mysqli_connect($servername,$username,$password,$dbname);
    
    
?>