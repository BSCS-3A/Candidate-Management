# Candidate-Management
V1.4 Is the Position Manager, it has a fully functional form panel for adding and editing positions, makeshift data table is functional as well.
V1.4.1 Is the Candidate Information Manager, working pagination, and search functions; add, edit, and delete functions are not yet available.

Both 1.4 and 1.4.1 isn't connected to any databases.

Landing Page anchors haven't been connected to proper links here in the GitHub version yet, but will be corrected ASAP.

All styles are still being compressed into one file.

User-side UI has only been started.
